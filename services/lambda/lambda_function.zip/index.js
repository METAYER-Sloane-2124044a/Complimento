const handler = async () => {
    return 'Hello World';
};

export default {
    handler,
};